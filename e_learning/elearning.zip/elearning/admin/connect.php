<?php
$conn = mysqli_connect('localhost','root','','e_learning')or die(mysqli_error());
?>
