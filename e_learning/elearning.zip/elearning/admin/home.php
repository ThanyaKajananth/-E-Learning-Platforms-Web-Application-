<?php include('header.php'); ?>
<?php include('session.php'); ?>
<body>

    <div class="row-fluid">
        <div class="span12">

            <?php include 'navbar.php'; ?>
            <div class="container">
                <div class="row-fluid">
                    <div class="span12">
                        <!--slider-->
                        <div class="slider-wrapper theme-default">

                            <div id="slider" class="nivoSlider">
                                <img src="images/01.jpg" data-thumb="images/toystory.jpg" alt="" />
                                <img src="images/02.jpg" data-thumb="images/toystory.jpg" alt="" />
                                <img src="images/03.jpg" data-thumb="images/wineries.jpg" alt="" />
                                <img src="images/04.jpg"  alt="" data-transition="slideInLeft" />
                                <img src="images/05.jpg"  alt="" data-transition="slideInLeft" />
                      
                            </div>

                        </div>
                        <!-- end slider -->
                    </div>
               
                </div>

                <?php include('footer.php'); ?>
            </div>

        </div>
    </div>





</body>
