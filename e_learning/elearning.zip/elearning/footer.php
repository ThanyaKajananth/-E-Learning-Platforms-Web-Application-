<br>
<div class="navbar  navbar-inverse">
    <div class="navbar-inner">
        <div class="footerindex">
           <center><img width="25" height="25" src="admin/img/bcas.png">&nbsp;BCAS E-Learning System  </center> 
            
            <div><center>
           
            <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Address:<a href="#">No: 256/2, Galle Road, Colombo 06, Sri Lanka.</a></span>
            
            <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">
					Tele:<a href="tel:+94 112 364 458">+94 112 364 458</a>
				</span>
                <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">
				Email:<a href="mailto:info@bcas.lk">bcas@gmail.com</a>
            </span>
              
              <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">Copyright © VBTS Tourism Management System.</span>
            </center></div>
        </div>
        
        
        
        
        
        
        
        
     
        <!-- modal -->
        <!-- mission -->
        <div id="mission" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
            <div class="modal-header">
            </div>
            <div class="modal-body">
                <div class="alert alert-info"><strong>BCAS Mission</strong></div>
                <p align="Justify">
                    To produce market-relevant quality human resources with ethics and social responsibility through innovation, research and skills to serve the nation and humanity at large.
                </p>

                <div class="alert alert-info"><strong>E-Learning Mission</strong></div>
                <p>
                    To provide a highly developed form of teaching through maximizing the use of technology which will somehow give an easier and efficient way of learning that will make them to be competitive and productive citizens of the society.
                </p>
            </div>
            <div class="modal-footer">
                <button class="btn" data-dismiss="modal" aria-hidden="true"><i class="icon-remove-sign icon-large"></i>&nbsp;Close</button>
            </div>
        </div>
        <!-- end mission -->
        <!-- vision -->
        <div id="vision" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
            <div class="modal-header">
            </div>
            <div class="modal-body">
                <div class="alert alert-info"><strong>BCAS Vision</strong></div>

                    <p align="justify">To become the premier private university in the South Asian Region </p>

                <div class="alert alert-info"><strong>E-Learning Vision</strong></div>
               
                To be able to prove to people that Filipinos also know how to cope up with the development in technology this will provide an easier way of teaching and a better form of learning.

            </div>
            <div class="modal-footer">
                <button class="btn" data-dismiss="modal" aria-hidden="true"><i class="icon-remove-sign icon-large"></i>&nbsp;Close</button>
            </div>
        </div>
        <!-- end vision -->
        <!--end modal -->

    </div>
</div>
</div>


