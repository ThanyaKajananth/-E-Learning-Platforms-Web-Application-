        <div id="slider" class="nivoSlider">
                        <img src="admin/images/01.jpg" data-thumb="images/01.jpg" alt="" />
                        <img src="admin/images/02.jpg" data-thumb="images/toystory.jpg" alt="" />
                        <img src="admin/images/03.jpg" data-thumb="images/wineries.jpg" alt="" />
                        <img src="admin/images/04.jpg"  alt="" data-transition="slideInLeft" />
                        <img src="admin/images/05.jpg"  alt="" data-transition="slideInLeft" />
                   
                    </div>
       